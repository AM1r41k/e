﻿using System;

namespace DapperLesson
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
